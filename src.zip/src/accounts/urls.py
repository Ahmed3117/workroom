from django.urls import path

from accounts.views import login_view, logoutUser, show_auth_page, show_profile_page, signup_view, update_profile
app_name = 'accounts'
urlpatterns = [
    path('show_auth_page/', show_auth_page,name="show_auth_page"),
    path('show_profile_page/', show_profile_page,name="show_profile_page"),
    path('login_view/', login_view,name="login_view"),
    path('signup_view/', signup_view,name="signup_view"),
    path('logout/', logoutUser,name="logout"),
    path('update_profile/', update_profile,name="update_profile"),
]