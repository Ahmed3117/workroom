from django.shortcuts import redirect, render
from django.contrib.auth import authenticate,login,logout
from django.contrib import messages
from .models import User
from django.db import IntegrityError
# Create your views here.

def show_auth_page(request):
    if request.user.is_authenticated:
        return redirect('/')
    return render(request, 'auth.html')

def show_profile_page(request):
    user = request.user
    context = {'user': user}
    return render(request, 'profile.html',context)


def login_view(request):
    username = request.POST.get('loginName')
    password = request.POST.get('loginPassword')
    user = authenticate(request, username=username, password=password)
    if user is not None:
        login(request, user)
        messages.success(request,'Login succeed')
        return redirect('/')
    else:
        messages.error(request,'Login failed')
        return redirect('accounts:show_auth_page')

def signup_view(request):
    name = request.POST.get('name')
    email = request.POST.get('email')
    username = request.POST.get('username')
    password1 = request.POST.get('password1')
    password2 = request.POST.get('password2')
    if username and email and (password1 == password2):
        user=""
        try:
            user = User.objects.get(username=username)
            messages.error(request,'user with that username is already exist')
        except:
            user = User.objects.create(name=name,username=username, email=email, password=password1)
            print(user)
            user.save()
            if user:
                login(request, user)
                messages.success(request,'Sign up succeed')
            else:
                messages.error(request,'Sign up failed')
            
    else:
        messages.error(request,'check you entered a valid username or email or password 1 = password 2')
    return redirect('/')
    
def logoutUser(request):
    logout(request)
    return redirect('/')


def update_profile(request):
    name = request.POST.get('name')
    email = request.POST.get('email')
    image=request.FILES.get('profile_image')
    try:
        user = request.user
        user.name = name
        user.email = email
        user.image = image
        user.save()
        messages.success(request,'Profile updated successfully')
    except IntegrityError :
        messages.error(request,'Email already exist')
    return redirect('accounts:show_profile_page')
    