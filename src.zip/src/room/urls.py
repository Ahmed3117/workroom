from django.urls import path

from room.views import addtodo, checkroomid, show_room_page, show_rooms_page,change_room_status,logout_room,togglestatus
app_name = 'room'
urlpatterns = [
    path('show_room_page/<int:id>/', show_room_page,name="show_room_page"),
    path('', show_rooms_page,name="show_rooms_page"),
    path('checkroomid/<int:id>/', checkroomid,name="checkroomid"),
    path('change_room_status/<int:id>/', change_room_status,name="change_room_status"),
    path('logout_room/<int:id>/', logout_room,name="logout_room"),
    path('togglestatus/<int:id>/', togglestatus,name="togglestatus"),
    path('addtodo/', addtodo,name="addtodo"),
    
]