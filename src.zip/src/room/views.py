from django.forms import model_to_dict
from django.http import JsonResponse
from django.shortcuts import redirect, render
from django.contrib import messages
from room.models import Room
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.views.decorators.http import require_http_methods
from todo.models import Todo
from chat.models import Message
# Create your views here.

def show_room_page(request,id):
    room=Room.objects.get(id=id)
    members = room.members.all()
    todos = Todo.objects.filter(room = room)
    messages = Message.objects.filter(room = room)
    context = {
            'members':members,
            'room':room,
            'todos':todos,
            'room_messages':messages
            }
    return render(request, 'room.html',context)

def show_rooms_page(request):
    
    if not request.user.is_authenticated:
        return redirect('accounts:show_auth_page')
    
    search_room_input = request.POST.get('search')
    
    user = request.user
    rooms = Room.objects.filter(members = user)
    if search_room_input:
        rooms = Room.objects.filter(room_id = search_room_input)
        if len(rooms) <1:
            messages.error(request,f'No Rooms with this id={search_room_input}')
            rooms = Room.objects.filter(members = user)

    paginator = Paginator(rooms, 1)
    page_number = request.GET.get('page')
    try:
        rooms = paginator.page(page_number)
    except PageNotAnInteger :
        rooms = paginator.page(1)
    except EmptyPage :
        rooms = paginator.page(1)
    context = {'rooms': rooms} 
        
    return render(request, 'rooms.html',context)


def checkroomid(request,id):
    sent_room_id = request.POST.get('roomid')
    room = Room.objects.get(id = id)
    actual_room_id = room.room_id
    if actual_room_id == sent_room_id:
        room.members.add(request.user)
        messages.success(request,'room id you entered is correct')
    else:
        messages.error(request,'room id you entered is not correct')
    return redirect('room:show_rooms_page')

def change_room_status(request, id):
    room = Room.objects.get(id=id)
    room.is_done = not room.is_done
    # if room.is_done == False:
    #     room.is_done = True
    # else:
    #     room.is_done = False
    room.save()
    return redirect('room:show_rooms_page')


def logout_room(request,id):
    room = Room.objects.get(id=id)
    room.members.remove(request.user)
    return redirect('room:show_rooms_page')

@require_http_methods(['POST'])
def addtodo(request):
    todo = None
    title = request.POST.get('title')
    id = request.POST.get('id')
    print(title)
    print(id)
    room = Room.objects.get(id=id)
    if title :
        todo = Todo(title=title,room=room)
        todo.save()
        todo = model_to_dict(todo)
    return JsonResponse({'todo':todo},safe=False)


def togglestatus(request,id):
    todo = Todo.objects.get(id=id)
    todo.is_done = not todo.is_done
    todo.save()
    return JsonResponse({'status':todo.is_done},safe=False)
    