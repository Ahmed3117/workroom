from django.urls import path
app_name = 'todo'
urlpatterns = [
    # path('room/', room,name="room"),
]